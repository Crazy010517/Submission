import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PartThree {
	public static int[] Sort(int[] list){
		for (int i = 0;i<list.length;i++){
			for (int k = 0;k<list.length-1;k++){
				if (list[k] > list[k+1]){
					int save = list[k+1];
					list[k+1] = list[k];
					list[k] = save;
				}
			}
		}
		return list;
	}
	
	public static void Solve(int amount,int[] coins){
		coins = Sort(coins);
		int coinI = 0;
		int[][] array = new int[coins.length][amount+1];
		for (int c = 0;c<coins.length;c++){
			coinI = c;
			for (int p = 0;p<amount+1;p++){	
				if (coinI == 0){ //coin value = 1
					array[c][p] = p;
				}else{
					int tempInd = coinI;
					int tempAmount = p;
					int coinCount = 0;
					while(tempInd >= 0){
						int tempValue = coins[tempInd];
						int count = (tempAmount/tempValue);
					//	System.out.println(tempAmount + " " + coins[tempInd] + " "+ count);
						coinCount = coinCount + count;
						tempAmount = tempAmount - (count * tempValue);
						tempInd = tempInd - 1;
					}
					if (p>=(coins[coinI])){
						array[c][p] = Math.min(array[c-1][p], array[c][p-coins[coinI]]+1);
						//	array[c][p] = Math.min(coinCount, array[c][p-coins[coinI]]);
					}else{
						if (c == 0){
							array[c][p] = p;
						}else{
							array[c][p] = array[c-1][p];
						}
					}
				}
			}
		}
		for (int r = 0;r<array.length;r++){
			for (int c = 0;c<array[0].length;c++){
				System.out.print(array[r][c]+" ");
			}
			System.out.println("");
		}
		System.out.println(array[array.length-1][array[0].length-1]);
		
		//Oh boy. Try catches >.<
		BufferedWriter bf = null;
		try {
			bf = new BufferedWriter(new FileWriter("coins2.out"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			bf.write(array[array.length-1][array[0].length-1]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args){
		Scanner scanner = null;
		try {
			scanner = new Scanner(new File("src/coins2.in"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int totalAmount = scanner.nextInt();
		int[] coins = new int[4];
		for (int i = 0;i<4;i++){
			coins[i] = scanner.nextInt();
		}
		//Solve(totalAmount,coins);
		
		Scanner scanner2 = null;
		try {
			scanner2 = new Scanner(new File("src/sum.in"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int r = scanner2.nextInt();
		int c = scanner2.nextInt();
		int[][] ReadArray = new int[r][c];
		for (int i = 0;i<r;i++){
			for (int k = 0;k<c;k++){
				ReadArray[i][k] = scanner2.nextInt();
			}
		}
		Bonus bonus = new Bonus();//piggybacking that main method 8-)
		bonus.CheapestPath(ReadArray);
	}
}
