import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Bonus {
	public void CheapestPath(int[][] array){
		int[][] newA = new int[array.length][array[0].length];
		
		newA[0][0] = array[0][0];
		
		int cTotal = array[0][0];
		for (int c = 1;c<newA[0].length;c++){
			cTotal = cTotal + array[0][c];
			newA[0][c] = cTotal;
		}
		
		int rTotal = array[0][0];
		for (int r = 1;r<newA.length;r++){
			rTotal = rTotal + array[r][0];
			newA[r][0] = rTotal;
		}
		
		for(int r = 1;r<newA.length;r++){
			for (int c = 1;c<newA[0].length;c++){
				newA[r][c] = Math.min(newA[r][c-1], newA[r-1][c]) + array[r][c];
			}
		}
		
		System.out.println(newA[newA.length-1][newA[0].length-1]);
	
		BufferedWriter bf = null;
		try {
			bf = new BufferedWriter(new FileWriter("sum.out"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			bf.write(newA[newA.length-1][newA[0].length-1]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
